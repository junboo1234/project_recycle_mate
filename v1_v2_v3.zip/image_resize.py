"""
pre_resize.py
train/val/test 이미지를 640x640으로 미리 리사이즈해서 저장
원본은 유지하고 새 폴더에 저장
"""
import os
from pathlib import Path
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

SRC_ROOT = r"C:\Users\43074\Desktop\RecycleMate\dataset-shrinked\processed\yolo_major9\images"
DST_ROOT = r"C:\Users\43074\Desktop\RecycleMate\dataset-shrinked\processed\yolo_major9_640\images"
SIZE = 640

def resize_one(args):
    src, dst = args
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        img = Image.open(src).convert("RGB")
        img = img.resize((SIZE, SIZE), Image.BILINEAR)
        img.save(dst, "JPEG", quality=95)
    except Exception as e:
        print(f"\n스킵: {src} ({e})")

paths = []
for split in ["train", "val", "test"]:
    src_dir = Path(SRC_ROOT) / split
    dst_dir = Path(DST_ROOT) / split
    for src in src_dir.glob("*.jpg"):
        dst = dst_dir / src.name
        paths.append((src, dst))

print(f"총 {len(paths)}장 리사이즈 시작")
with ThreadPoolExecutor(max_workers=8) as ex:
    list(tqdm(ex.map(resize_one, paths), total=len(paths)))
print("완료")