v1 → v2

1. val 루프 BatchNorm 토글 버그 수정

변경사항: no_grad 밖에서 model.train() 고정 후 진입
수정 이유: v8DetectionLoss는 train 모드의 raw feature map을 입력으로 요구한다. 기존 코드는 no_grad 블록 안에서 model.eval() → model.train()을 토글해서 BatchNorm의 running mean/variance가 val 데이터로 오염됐다.
수정하지 않았을 때: val_loss 수치가 부정확해지고, 그 수치 기준으로 best.pt가 선택되므로 실제로 가장 좋은 가중치가 저장되지 않을 수 있다.



2. Warmup + Cosine 스케줄러 추가

변경사항: CosineAnnealingLR → epoch 0~2 선형 증가 + epoch 3~99 Cosine decay
수정 이유: pretrained 모델에 LR 1e-3을 warmup 없이 바로 적용하면 초반 gradient가 크게 튀어 학습이 불안정해진다. warmup은 pretrained fine-tuning의 표준 관행이다.
수정하지 않았을 때: 초반 몇 epoch에서 loss가 튀거나 발산할 수 있고, 좋은 pretrained 가중치가 초반에 망가질 수 있다.



3. worker 수 조정

변경사항: workers=4 → workers=6 (단, 이미지 사전 리사이즈 후에는 다시 조정 필요) 
수정 이유: 원본 이미지가 장당 평균 3.6MB로 커서 worker=4로는 CPU 데이터 로딩이 GPU 연산을 못 따라가 GPU 사용률이 낮았다.
수정하지 않았을 때: GPU가 데이터를 기다리느라 놀게 되어 학습 속도가 불필요하게 느려진다.

- 기타 수정사항
   : 이미지 리사이징에 시간이 오래 걸리는 것을 확인. 미리 리사이징하는 코드 image_resizing.py 추가
ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
v2 → v3
버그 수정

모델 nc 교체 누락 수정
YOLO("yolov8n.pt") 그대로 사용 → 80클래스로 학습되던 문제
DetectionModel("yolov8n.yaml", nc=9)로 9클래스 구조 생성 후 pretrained backbone/neck 가중치만 이식

경로 변경

DATASET_YAML, SAVE_DIR → yolo_major9 → yolo_major9_640 / baseline_v3 (리사이즈된 이미지)